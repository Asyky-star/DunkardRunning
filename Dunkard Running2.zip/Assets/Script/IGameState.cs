﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IGameState 
{
    /// <summary>
    /// 游戏状态名称
    /// </summary>
    private string m_StateNmae = "IGameState";

    public string StateName
    {
        get { return m_StateNmae; }
        set { m_StateNmae = value; }
    }

   // protected SceneStateController m_Controller = null;
}
